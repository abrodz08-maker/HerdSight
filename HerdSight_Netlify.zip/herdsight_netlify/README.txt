HerdSight — Netlify-ready static deployment

1. Sign in to Netlify and open Add new project > Deploy manually.
2. Drag and drop the entire HerdSight_Netlify.zip file if Netlify accepts ZIP deployment, or unzip and drag the herdsight_netlify folder into the deploy area.
3. The site starts at index.html. data.json contains the 10,000 synthetic cattle records.

This is a browser-based port of the original Streamlit/Python research prototype. It includes the original rule-based risk scoring, 10,000 synthetic cattle, feedlot filtering, 45-day cohort, scenario assumptions, capacity checks, CSV exports, summary downloads, and CSV/XLSX uploads. Charts and tables use browser-native components rather than Streamlit/Plotly. XLSX upload uses a public SheetJS script and requires internet access; CSV upload works without it. All analysis is client-side. The original submission ZIP is separate and unchanged.

Important: No clinical validation; scenarios are hypothetical. Veterinary oversight is required.
